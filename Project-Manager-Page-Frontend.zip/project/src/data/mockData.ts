import { Bug, Developer, Project } from '../types';

export const mockDevelopers: Developer[] = [
  {
    id: '1',
    name: 'Alice Johnson',
    email: 'alice@example.com',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
  },
  {
    id: '2',
    name: 'Bob Smith',
    email: 'bob@example.com',
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&h=100&fit=crop',
  },
  {
    id: '3',
    name: 'Carol Williams',
    email: 'carol@example.com',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
  },
];

export const mockBugs: Bug[] = [
  {
    id: '1',
    title: 'Login page not responsive on mobile',
    description: 'The login form elements overlap on mobile devices smaller than 375px width.',
    priority: 'HIGH',
    status: 'TO_DO',
    createdBy: mockDevelopers[0],
    createdAt: '2024-03-10T10:00:00Z',
    dueDate: '2024-03-20T00:00:00Z',
  },
  {
    id: '2',
    title: 'API rate limiting not working',
    description: 'Users can make unlimited API calls without being rate limited.',
    priority: 'MEDIUM',
    status: 'IN_PROGRESS',
    createdBy: mockDevelopers[1],
    assignedTo: mockDevelopers[2],
    createdAt: '2024-03-08T15:30:00Z',
    dueDate: '2024-03-18T00:00:00Z',
  },
  {
    id: '3',
    title: 'Password reset email not sending',
    description: 'Users are not receiving password reset emails when requested.',
    priority: 'HIGH',
    status: 'COMPLETED',
    createdBy: mockDevelopers[2],
    assignedTo: mockDevelopers[1],
    createdAt: '2024-03-05T09:15:00Z',
    dueDate: '2024-03-15T00:00:00Z',
    completedAt: '2024-03-12T16:45:00Z',
  },
];

export const mockProjects: Project[] = [
  {
    id: '1',
    name: 'E-commerce Platform',
    startDate: '2024-01-15T00:00:00Z',
    manager: mockDevelopers[0],
    bugCount: mockBugs.length,
    bugs: mockBugs,
  },
  {
    id: '2',
    name: 'Mobile Banking App',
    startDate: '2024-02-01T00:00:00Z',
    manager: mockDevelopers[1],
    bugCount: 2,
    bugs: mockBugs.slice(0, 2),
  },
];